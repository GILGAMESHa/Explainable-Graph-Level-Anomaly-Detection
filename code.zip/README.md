# Explainable Graph Level Anomaly Detection
## Requirements
python == 3.9

## run
run main.py